# Agent Pipeline Walkthrough
**Skill-First Autonomous Freelance Bid Engine**
#AISeekho 2026 · Google Antigravity Hackathon · Challenge 1

---

## Pipeline Architecture

Every call to `POST /api/bids` initiates a deterministic 4-agent pipeline. Agents run sequentially; each agent writes real-time trace entries to the `trace_logs` PostgreSQL table before proceeding.

```
JobInput
  │
  ▼
┌─────────────────────────────┐
│  AGENT 1: Intake_Agent_Alpha │  ← PARSE_JOB_SIGNALS
│  Model: GPT-4.1 (OpenAI     │
│  compatible via Vertex AI)  │
└─────────────┬───────────────┘
              │ ExtractedSignals { jobType, urgency,
              │   keyRequirements, matchedSkills, missingSkills }
              ▼
┌─────────────────────────────┐
│  AGENT 2: Audit_Agent_Alpha  │  ← GEMINI_BEHAVIORAL_AUDIT
│  Model: Gemini 2.5 Flash    │  ← CONTRADICTION_CHECK
│  (Vertex AI / @google/genai)│
└─────────────┬───────────────┘
              │
       ┌──────┴────────┐
  CRITICAL?           LOW_RISK?
       │                    │
       ▼                    ▼
REJECT_AND_LOG    ┌─────────────────────────────┐
(writes outbox_   │  AGENT 3: Matching_Agent_Beta │  ← COMPUTE_MATCH_SCORE
bids row, halts   │  (Deterministic skill-match) │
pipeline)         └─────────────┬───────────────┘
                                │ matchScore (0–100%)
                                ▼
                  ┌─────────────────────────────┐
                  │ AGENT 4: Execution_Agent_Omega│  ← ORCHESTRATE_ACTION
                  │ Model: GPT-4.1               │  ← GENERATE_PROPOSAL
                  │                             │  ← WRITE_OUTBOX_TRANSACTION
                  └─────────────────────────────┘
```

---

## Agent 1: Intake_Agent_Alpha

**Operation:** `PARSE_JOB_SIGNALS`

**Inputs:** `title`, `description`, `requiredSkills[]`, `declaredBudget`, `clientHistoricSpend`, `clientRating`, `clientStatus`

**Process:**
- Calls GPT-4.1 via the Vertex AI OpenAI-compatible endpoint with a structured extraction prompt
- Prompt instructs the model to classify: job type (fixed-price vs hourly), urgency (STANDARD | URGENT | RUSH), key requirement list (canonical normalised form), matched skills (intersection with developer profile), missing skills (complement)
- Falls back to a deterministic keyword-matching algorithm if the LLM call fails — no unhandled rejections

**Outputs:** `ExtractedSignals` object persisted in memory for downstream agents

**Trace Entries:**
```
RUNNING  → Intake_Agent_Alpha | PARSE_JOB_SIGNALS | Extracting signals from: <title>
SUCCESS  → Intake_Agent_Alpha | PARSE_JOB_SIGNALS | Extracted N required skills. Urgency: X. Matched M/N skills.
```

---

## Agent 2: Audit_Agent_Alpha (Dual Evaluation)

### 2a. Gemini Behavioral Audit

**Operation:** `GEMINI_BEHAVIORAL_AUDIT`

**Trigger condition:** `clientReviewsText` is non-empty (trimmed length > 0)

**Process:**
- Calls `gemini-2.5-flash` via `@google/genai` with `GEMINI_API_KEY`
- System prompt instructs Gemini to analyse the review corpus for:
  - Mid-project cancellations
  - Scope creep and requirement escalation
  - Delayed or disputed payment records
  - Communication breakdown indicators
  - Adversarial or toxic language patterns
- Response schema enforces structured JSON: `{ behavioralRiskLevel: "LOW"|"MEDIUM"|"CRITICAL", behavioralSummary: string }`
- Falls back to `{ behavioralRiskLevel: "N/A", behavioralSummary: "" }` on API failure

**Trace Entries:**
```
RUNNING  → Audit_Agent_Alpha | GEMINI_BEHAVIORAL_AUDIT | Analyzing client review corpus...
SUCCESS  → Audit_Agent_Alpha | GEMINI_BEHAVIORAL_AUDIT | behavioralRiskLevel=<level>
WARN     → Audit_Agent_Alpha | GEMINI_BEHAVIORAL_AUDIT | Gemini unavailable, using fallback
```

### 2b. Quantitative Contradiction Check

**Operation:** `CONTRADICTION_CHECK`

**Formula (exact implementation):**
```
contradictionScore = Math.abs(declaredBudget - clientHistoricSpend) / declaredBudget

Gate: contradictionScore > 0.85 AND clientHistoricSpend < 50
  → riskClassification = "CRITICAL_CONTRADICTION_SUPPRESSED"
  → agentDecision = "REJECT_AND_LOG"
  → Pipeline halts
```

**Additional override conditions:**
- `clientRating < 2.0` → `CRITICAL_CONTRADICTION_SUPPRESSED`
- `behavioralRiskLevel === "CRITICAL"` → `CRITICAL_CONTRADICTION_SUPPRESSED`

**On REJECT:** Before returning, inserts a complete row into `outbox_bids` with `agentDecision: "REJECT_AND_LOG"` and the rejection reason as the proposal text — ensuring the bid appears in history, statistics, and the Outbox screen.

**Trace Entries (REJECT path):**
```
HALT → Audit_Agent_Alpha | CONTRADICTION_CHECK | Halt: Source credibility or behavioral threat detected.
SUCCESS → Execution_Agent_Omega | WRITE_OUTBOX_TRANSACTION | Rejected bid logged to outbox. ID: <id>
```

---

## Agent 3: Matching_Agent_Beta

**Operation:** `COMPUTE_MATCH_SCORE`

**Process:**
- Computes `matchScore = (matchedSkills.length / requiredSkills.length) * 100`
- Computes and logs the precise `contradictionScore` value
- Emits final `riskClassification` and `contradictionScore` in the trace message for auditability

**Trace Entries:**
```
RUNNING → Matching_Agent_Beta | COMPUTE_MATCH_SCORE | Analyzing match for: <title>
SUCCESS → Matching_Agent_Beta | COMPUTE_MATCH_SCORE | Match score: X%, Contradiction score: 0.XXXX, Risk: <classification>
```

---

## Agent 4: Execution_Agent_Omega (3-Step Action Chain)

**Operation Sequence:** `ORCHESTRATE_ACTION` → `GENERATE_PROPOSAL` → `WRITE_OUTBOX_TRANSACTION`

### Step 1 — Outbox Transaction Commit (WRITE_OUTBOX_TRANSACTION)

Inserts a complete `outbox_bids` row via Drizzle ORM before any downstream action. Fields committed:
- `jobTitle`, `jobDescription`, `matchScore`, `riskClassification`, `agentDecision`
- `requiredSkills`, `declaredBudget`, `clientHistoricSpend`
- `behavioralRiskLevel`, `behavioralSummary`
- `proposal` (inserted after Step 2)

This follows the Transactional Outbox pattern — the record is durable before proposal synthesis begins.

### Step 2 — Tailored Proposal Draft (GENERATE_PROPOSAL)

- Calls GPT-4.1 via Vertex AI OpenAI-compatible endpoint
- Composite prompt includes: job description, extracted signals, matched/missing skills, developer profile, match score
- Model produces a technically grounded, skill-referenced freelance proposal
- Falls back to deterministic template if LLM call fails

### Step 3 — Global Network State Push

- Returns the complete `AgentResult` payload synchronously
- Web and mobile clients receive: `agentDecision`, `matchScore`, `riskClassification`, `behavioralRiskLevel`, `behavioralSummary`, `extractedSignals`, `proposal`, `bidId`
- TanStack Query cache invalidation triggers re-fetch of `listBids` and `getBidStats` across all open clients

**Trace Entries:**
```
RUNNING  → Execution_Agent_Omega | ORCHESTRATE_ACTION | Deciding action for: <title>
RUNNING  → Execution_Agent_Omega | GENERATE_PROPOSAL  | Generating proposal via GPT-4.1...
SUCCESS  → Execution_Agent_Omega | GENERATE_PROPOSAL  | Proposal generated successfully
SUCCESS  → Execution_Agent_Omega | WRITE_OUTBOX_TRANSACTION | Bid committed to outbox. ID: <id>
```

---

## Status Code Reference

| Code | Meaning | When Used |
|---|---|---|
| `RUNNING` | Agent has started an operation | Entry point of every agent operation |
| `SUCCESS` | Operation completed normally | Clean execution with full output |
| `HALT` | Pipeline suppressed by risk gate | Contradiction or CRITICAL behavioral risk |
| `WARN` | Degraded execution via fallback | LLM unavailable, deterministic fallback used |
